
    el blog de giltesa
    https://giltesa.com

    Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
    https://creativecommons.org/licenses/by-nc-sa/4.0/

    Reconocimiento-NoComercial-CompartirIgual 4.0 Internacional (CC BY-NC-SA 4.0)
    https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es_ES