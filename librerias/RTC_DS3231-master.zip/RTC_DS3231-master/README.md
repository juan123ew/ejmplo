# RTC_DS3231

RTC_DS3231 es una librería para Arduino que permite controlar tanto el Maxim DS1307 como el DS3231.
Mas información aquí:

https://giltesa.com/2012/09/02/libreria-gds1307-para-rtc

https://giltesa.com/2014/10/15/actualizacion-1-4-de-la-libreria-rtc-para-reloj-dallas-ds1307-y-ds3231


## Licencia

Este proyecto está licenciado bajo la licencia **Creative Commons** de tipo: **[Reconocimiento-NoComercial-CompartirIgual 4.0 Internacional (CC BY-NC-SA 4.0)](https://creativecommons.org/licenses/by-nc-sa/3.0/deed.es_ES)**. Consulte el archivo [LICENSE.md](LICENSE.md) para obtener más información.